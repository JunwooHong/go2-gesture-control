# Remote-controlled stand-up observation

Source: `go2_20261118_143015_795876.jsonl`; user confirms pressing **L2 + X** on the physical remote.

The diagnostic program was read-only. It ended on operator Ctrl+C, with `move_sends=0`, `stop_sends=0`, `failed=false`. No SDK posture action was issued in this run.

Regular sport-state samples (local time, UTC+01:00):

| First observed | FSM | Body height |
| --- | --- | --- |
| 14:30:17.840 | 1001 | 0.0824 m |
| 14:30:18.371 | 2004 | 0.0824 m; subsequently rises |
| 14:30:19.876 | 100 | 0.3231 m |

Low-frequency sport-state samples show the same ordered sequence. The last regular sample has height 0.3152 m. The approximately 1.5 seconds in 2004 is the sampled transition interval, not a configurable API duration.

Sampled hardware fault summaries have an empty reason and zero fault values for all twelve leg motors. `errorlist_received=false`; this does not establish complete fault coverage.

## Interpretation and implementation boundary

- This establishes the observed remote sequence from prone/damping back to upright for this robot. It does not establish which SDK RPC the remote action corresponds to.
- Official V2 documentation identifies 1001 as damping and 100 as free walking. Its published table does not list 2004. Here, 2004 is described only as the state observed during this remote rise, not as a documented universal FSM name or API ID.
- Existing native posture test rejects 1001 and 2004, so its present StandDown/StandUp pair does not support this observed sequence. Repeating the same test is not a fix.
- Official `StandUp()` describes locked standing. `RecoveryStand()` describes recovery from a prone or overturned position to balanced standing. This makes RecoveryStand a candidate for a separate supervised validation; it does not prove equivalence with L2 + X or safe timing on this firmware.
- No whitelist, safety check, action mapping, or installed SDK was changed based on this observation. No RecoveryStand command has been issued by the assistant.
- Hand-gesture stand-up remains unverified. The already demonstrated remote operation remains the available way to stand from this state.

Official reference: https://support.unitree.com/home/zh/developer/Motion_Services_Interface_V2.0
